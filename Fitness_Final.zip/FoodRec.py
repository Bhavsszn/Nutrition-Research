import pandas as pd
import numpy as np
from scipy.optimize import minimize

from tkinter import *
from tkinter import simpledialog

def load_data(filepath):
    # Assuming CSV format; adjust if different
    return pd.read_csv(filepath)

def get_user_dri():
    print("Enter your daily nutritional requirements.")

    # Input calories
    inp = simpledialog.askstring("Calories", "Input target calories")
    while inp.isnumeric() is False:
        inp = simpledialog.askstring("Calories", "Input target calories")
    calories = int(inp)
    # Input protiens
    inp = simpledialog.askstring("Protein", "Input target protein amount")
    while inp.isnumeric() is False:
        simpledialog.askstring("Protein", "Input target protein amount")
    protein = int(inp)
    # Input carbs
    inp = simpledialog.askstring("Carbs", "Input target carbs amount")
    while inp.isnumeric() is False:
        inp = simpledialog.askstring("Carbs", "Input target carbs amount")
    carbs = int(inp)
    # Input fats
    inp = simpledialog.askstring("Fats", "Input target fat amount")
    while inp.isnumeric() is False:
        inp = simpledialog.askstring("Fats", "Input target fat amount")
    fats = int(inp)
    # Return
    return {'Calories (kcal)': calories, 'Protein (g)': protein, 'Carbohydrates (g)': carbs, 'Total Fat (g)': fats}

def can_meet_requirements(food_data, dri):
    max_nutrients = food_data.max() * 10  # Assuming maximum 10 servings per food item
    return all(max_nutrients[nutrient] >= dri[nutrient] for nutrient in dri.keys())

def recommend_foods(dri, food_data):
    nutrients = list(dri.keys())  # dynamically build list based on DRI keys

    def objective(x):
        penalty = sum(max(0, dri[n] - np.dot(food_data[n], x))**2 for n in nutrients)
        return penalty

    constraints = [{'type': 'ineq', 'fun': lambda x, n=n: np.dot(food_data[n], x) - dri[n]} for n in nutrients]

    bounds = [(0, 10) for _ in range(len(food_data))]  # Adjust based on typical serving sizes

    x0 = np.zeros(len(food_data))

    result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints)

    recommended_foods = []
    if result.success:
        recommended_foods = [(food_data['name'].iloc[i], result.x[i]) for i in range(len(food_data)) if result.x[i] > 0.01]
        print("Optimization succeeded.")
    else:
        print("Optimization failed: ", result.message)

    return recommended_foods

def print_recommendations(recommendations):
    if recommendations:
        print("\nRecommended Food Servings:")
        for food, serving in recommendations:
            print(f"{food}: {serving:.2f} servings")
    else:
        print("No recommendations could be made that meet all dietary requirements within the serving limits.")

def main():
    food_data = load_data('Emoji Diet Nutritional Data (g) - EmojiFoods (g).csv')  # Ensure the path is correctly specified
    user_dri = get_user_dri()
    if can_meet_requirements(food_data, user_dri):
        print("Dataset can potentially meet the requirements.")
        recommendations = recommend_foods(user_dri, food_data)
        print_recommendations(recommendations)
    else:
        print("Dataset cannot meet the requirements with the given maximum servings.")

#if __name__ == "__main__":
#    main()