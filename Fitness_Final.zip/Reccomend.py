import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from tkinter import *
from tkinter import messagebox

from surprise import Dataset, Reader, SVD
from surprise.model_selection import cross_validate

header = ['Exercise', 'Weight90', 'Weight108', 'Weight126', 'Type']
df = pd.read_csv('calorie.csv', header=None, names=header)
df = pd.melt(df, id_vars=['Exercise', 'Type'], value_vars=['Weight90', 'Weight108', 'Weight126'], var_name='Weight', value_name='Calories')

dp = pd.read_csv('profile.txt')

reader = Reader(rating_scale=(0, 500))

# Load data into Surprise dataset
dataset = Dataset.load_from_df(df[['Exercise', 'Weight', 'Calories']], reader)

# Define the SVD algorithm
algo = SVD()

# Perform cross-validation
cross_validate(algo, dataset, measures=['RMSE', 'MAE'], cv=5, verbose=True)

# Train the algorithm on the whole dataset
trainset = dataset.build_full_trainset()
algo.fit(trainset)

def rec(profile):
    # Now, let's say you want recommendations for a specific user
    user_id = profile.name

    # Get a list of all possible exercises
    all_exercises = df['Exercise'].unique()

    #print("Available exercises:")
    #print(all_exercises)

    # Filter out exercises that the user has already rated
    already_rated = df[df['Weight'] == 90]['Exercise'].unique()  # Assuming all users have the same exercise history
    exercises_to_predict = [exercise for exercise in all_exercises if exercise != profile.activity]

    # Predict ratings for exercises the user hasn't rated yet
    predictions = [algo.predict(user_id, exercise) for exercise in exercises_to_predict]

    # Sort the predictions by estimated rating
    predictions.sort(key=lambda x: x.est, reverse=True)

    # Print the top recommended exercises
    for pred in predictions[:10]:  # Print top 10 recommendations
        recMsg = ("Reccomendation: " + str(pred.iid) + "\nEstimated Calories Burned:" + str(pred.est))
        messagebox.showinfo("Reccomended Activity", recMsg)