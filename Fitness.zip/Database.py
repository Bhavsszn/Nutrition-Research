import tkinter
from tkinter import *
from tkinter.ttk import *
from tkinter import simpledialog
import random

import tk

#Read CSV and create array
f = open("calorie.csv", "r")
v = []
for i in f:
    v.append(f.readline())
f.close()
#Just to make sure
print(v)

#Read Profiles and create array
f = open("profile.txt", "r")
pData = []
for i in f:
    pData.append(f.readline())
f.close()
#Also to make sure
print(pData)
pData.pop(len(pData) - 1)

#Eliminate new line declarations
i = 0
while (i < len(pData)):
    pData[i].replace('\n','')
    print(pData[i])
    i += 1

pClassLi = []

class NewWindow(Toplevel):
    def __init__(self, master = None):
        super().__init__(master = master)
        self.title("Meyer Banking")
        self.geometry("500x200")
        label = Label(self, text = "Welcome to Meyer Banking")
        label.pack

class Profile:
    def __init__(self):
        self.name = ""
        self.weight = 0
        self.height = 0
        self.activity = ""
        self.food = ""

    def findExcerciseMatch(self):
        refStr = []
        i = 0
        while i < len(v):
            refStr = v[i].split(",")
            if refStr[0] == self.activity:
                print("Match found: " + refStr[0] + ", Type " + refStr[4])
                if refStr[4] == "0":
                    print("You seem to be quite laidback.")
                elif refStr[4] == "1":
                    print("You seem to gravitate towards aerobics.")
                break
            i += 1
    def define(self):
        inp = ""
        self.name = simpledialog.askstring("Set Preference","Input your name")

        inp = simpledialog.askstring("Weight","Input weight")
        if inp.isnumeric(): self.weight = int(inp)

        inp = simpledialog.askstring("Height","Input height")
        if inp.isnumeric(): self.height = float(inp)

        inp = simpledialog.askstring("Activities","Input favorite activities")
        self.activity = inp

        inp = simpledialog.askstring("Food","Input favorite foods")
        self.food = inp

        expForm = "%s,%d,%d,%s,%s\n" % (self.name, self.weight, self.height, self.activity, self.food)
        print(expForm)
        pData.append(expForm)

        w = open("profile.txt", "a")
        w.write(expForm)
        w.close()

        self.findExcerciseMatch()

def loadAllProfiles(li):
    i = 0
    while i < len(li) - 1:
        striArr = li[i].split(',')
        pClassLi.append(Profile())
        pClassLi[i].name = striArr[0]
        pClassLi[i].weight = striArr[1]
        pClassLi[i].height = striArr[2]
        pClassLi[i].activity = striArr[3]
        pClassLi[i].food = striArr[4]
        print("New Profile: " + pClassLi[i].name)
        i += 1
def loadProfile(li):
    name = simpledialog.askstring("Name","Please input user name")
    i = 0
    while i < len(li):
        striArr = li[i].split(',')
        if striArr[0] == name:
            print("Profile found")
            print(li[i])
        i += 1

def newProfile(li):
    li.append(Profile())
    li[len(li) - 1].define()

loadAllProfiles(pData)

loadProfile(pData)

master = Tk()
master.geometry("500x500")
label = Label(master, text = "BEHOLD, The Reccomendinator")
label.pack(side = TOP, pady = 10)

T = Text(master, height = 10, width = 52)
T.insert(END,pData)

nP = Button(text = "New User Profile")
nP.bind("<Button>", lambda e: newProfile(pClassLi))

lP = Button(text = "Load User Profile")
lP.bind("<Button>", lambda e: loadProfile(pData))

T.pack(padx = 5, pady = 2)
nP.pack(padx = 2, pady = 1)
lP.pack(padx = 2, pady = 0)

mainloop()