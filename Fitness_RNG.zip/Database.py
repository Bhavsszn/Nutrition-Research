import tkinter
from tkinter import *
from tkinter.ttk import *
from tkinter import messagebox
from tkinter import simpledialog
import random
import tk

#Read CSV and create array
f = open("calorie.csv", "r")
v = []
for i in f:
    v.append(f.readline())
f.close()
#Just to make sure
print(v)

#Read Profiles and create array
f = open("profile.txt", "r")
pData = []
for i in f:
    pData.append(f.readline())
    pData.append(f.readline())
    pData.append(f.readline())
f.close()
#Also to make sure
print(pData)

#Eliminate new line declarations
i = 0
while (i < len(pData)):
    pData[i].replace('\n','')
    print(pData[i])
    i += 1

pClassLi = []

class NewWindow(Toplevel):
    def __init__(self, master = None):
        super().__init__(master = master)
        self.title("Meyer Banking")
        self.geometry("500x200")
        label = Label(self, text = "Welcome to the Fitness Reccomendinator")
        label.pack

class Profile:
    def __init__(self):
        self.name = ""
        self.weight = 0
        self.height = 0
        self.activity = ""
        self.food = ""

    def findExcerciseMatch(self):
        refStr = []
        i = 0
        while i < len(v) - 1:
            refStr = v[i].split(",")
            if refStr[0].lower() == self.activity.lower():
                print("Match found: " + refStr[0] + ", Type " + refStr[4])
                refStr[4].replace('\n','')
                reccomendation(refStr[4])
                break
            i += 1
    def define(self):
        inp = ""
        self.name = simpledialog.askstring("Set Preference","Input your name")

        inp = simpledialog.askstring("Weight","Input weight")
        if inp.isnumeric(): self.weight = int(inp)

        inp = simpledialog.askstring("Height","Input height in feet.")
        if inp.isnumeric(): self.height = float(inp)

        inp = simpledialog.askstring("Height", "Input additional height in inches")
        if inp.isnumeric(): self.height += float(inp)/12

        inp = simpledialog.askstring("Activities","Input favorite activities")
        self.activity = inp

        inp = simpledialog.askstring("Food","Input favorite foods")
        self.food = inp

        expForm = "%s,%d,%d,%s,%s\n" % (self.name, self.weight, self.height, self.activity, self.food)
        print(expForm)
        pData.append(expForm)

        w = open("profile.txt", "a")
        w.write(expForm)
        w.close()

        self.findExcerciseMatch()

def loadAllProfiles(li):
    i = 0
    while i < len(li):
        if(li[i] != ""):
            striArr = li[i].split(',')
            pClassLi.append(Profile())
            pClassLi[i].name = striArr[0]
            pClassLi[i].weight = striArr[1]
            pClassLi[i].height = striArr[2]
            pClassLi[i].activity = striArr[3]
            pClassLi[i].food = striArr[4]
            print("New Profile: " + pClassLi[i].name)
        i += 1
def loadProfile(li):
    name = simpledialog.askstring("Name","Please input user name")
    i = 0
    while i < len(li):
        if li[i].name == name:
            print("Profile found: " + li[i].name)
            li[i].findExcerciseMatch()
        i += 1

def reccomendation(ty):
    refStr = []
    matches = []
    rec = ""
    i = 0
    #Assemble array
    while i < len(v) - 1:
        refStr = v[i].split(",")
        refStr[4].replace('\n','')
        if refStr[4] == ty: matches.append(refStr[0])
        i += 1
    #Produce random reccomendation
    rec = matches[random.randint(0,len(matches))]
    messagebox.showinfo("Reccomended Activity", "We reccomend " + rec + " as an exercise activity to undertake.")



def newProfile(li):
    li.append(Profile())
    li[len(li) - 1].define()

loadAllProfiles(pData)

master = Tk()
master.geometry("500x500")
label = Label(master, text = "BEHOLD, The Reccomendinator")
label.pack(side = TOP, pady = 10)

T = Text(master, height = 10, width = 52)
T.insert(END,pData)

nP = Button(text = "New User Profile")
nP.bind("<Button>", lambda e: newProfile(pClassLi))

lP = Button(text = "Load User Profile")
lP.bind("<Button>", lambda e: loadProfile(pClassLi))

T.pack(padx = 5, pady = 2)
nP.pack(padx = 2, pady = 1)
lP.pack(padx = 2, pady = 0)

mainloop()