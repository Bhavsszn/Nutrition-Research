import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import joblib

data_path = 'calorie.csv'
data = pd.read_csv(data_path)

data.head()

# Step 1: Fill NaN values in the '0' column
data['0'].fillna(0, inplace=True)  # Filling NaN with 0 to represent light activity

# Step 2: Normalize caloric data for consistency
exercise_columns = ['90', '108', '126']
exercise_similarity = data[exercise_columns].apply(lambda x: x / x.max(), axis=0)

# Step 3: Calculate item-item similarity using cosine similarity (excluding 'Type' column for consistency)
similarity_matrix = cosine_similarity(exercise_similarity)  # Item-item similarity matrix

# Step 4: Create a dictionary mapping exercise names to similarity scores
exercise_names = data['Weights'].tolist()

exercise_recommendations = {
    exercise_names[i]: {exercise_names[j]: similarity_matrix[i][j] for j in range(len(exercise_names)) if i != j}
    for i in range(len(exercise_names))
}

# Step 5: Create a function to get recommendations with a specific "Type" classification
def get_filtered_recommendations(exercise_name, activity_type=0, threshold=0.99, top_n=5):
    similar_exercises = exercise_recommendations.get(exercise_name, {})
    filtered_exercises = {k: v for k, v in similar_exercises.items() if data.loc[data['Weights'] == k, '0'].iloc[0] == activity_type and v >= threshold}
    sorted_exercises = dict(sorted(filtered_exercises.items(), key=lambda item: item[1], reverse=True))
    return list(sorted_exercises.items())[:top_n]

filtered_recommendations = get_filtered_recommendations('Aerobics', activity_type=1, threshold=0.99, top_n=5)

filtered_recommendations
